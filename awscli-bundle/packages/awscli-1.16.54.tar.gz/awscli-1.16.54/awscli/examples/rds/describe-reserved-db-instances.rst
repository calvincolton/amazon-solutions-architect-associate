**To describe reserved DB instances**

This example describes reserved DB instances (if any) for the current AWS account::

    aws rds describe-reserved-db-instances 

